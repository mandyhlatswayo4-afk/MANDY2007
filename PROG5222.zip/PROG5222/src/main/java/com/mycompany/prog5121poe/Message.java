package com.mycompany.prog5121poe;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Message {

    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;

    private static int totalMessages = 0;
    private static int messageNumber = 0;

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        messageNumber++;
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random random = new Random();
        long number = 1000000000L + random.nextInt(900000000);
        return String.valueOf(number);
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (recipient != null
                && recipient.matches("^\\+27[0-9]{9}$")) {
            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code.";
    }

    public String createMessageHash() {
        if (messageText == null || messageText.trim().isEmpty()) {
            return messageID.substring(0, 2) + ":" + messageNumber + ":";
        }

        String[] words = messageText.trim().split("\\s+");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        return messageID.substring(0, 2) + ":"
                + messageNumber + ":"
                + (firstWord + lastWord).toUpperCase();
    }

    public String SentMessage(String choice) {
        if (choice == null) {
            return "Invalid choice.";
        }

        switch (choice.trim().toLowerCase()) {

            case "send":
                totalMessages++;
                return "Message successfully sent.";

            case "disregard":
            case "discard":
                return "Press 0 to delete the message.";

            case "store":
                return storeMessage();

            default:
                return "Invalid choice.";
        }
    }

    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    public String storeMessage() {
        try (FileWriter writer = new FileWriter("messages.json", true)) {

            String safeRecipient = recipient
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"");

            String safeMessage = messageText
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r");

            String json = "{"
                    + "\"messageID\":\"" + messageID + "\","
                    + "\"messageHash\":\"" + messageHash + "\","
                    + "\"recipient\":\"" + safeRecipient + "\","
                    + "\"message\":\"" + safeMessage + "\""
                    + "}" + System.lineSeparator();

            writer.write(json);

            return "Message successfully stored.";

        } catch (IOException e) {
            return "Error storing message: " + e.getMessage();
        }
    }

    public int returnTotalMessages() {
        return totalMessages;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }
    public static ArrayList<Message> loadStoredMessages() {
    ArrayList<Message> messages = new ArrayList<>();

    try (BufferedReader reader = new BufferedReader(
            new FileReader("messages.json"))) {

        String line;

        while ((line = reader.readLine()) != null) {
            JsonObject obj = JsonParser.parseString(line).getAsJsonObject();

            Message loaded = new Message(
                    obj.get("recipient").getAsString(),
                    obj.get("message").getAsString()
            );

            loaded.messageID = obj.get("messageID").getAsString();
            loaded.messageHash = obj.get("messageHash").getAsString();

            messages.add(loaded);
        }

    } catch (IOException e) {
        System.out.println("Could not load stored messages: " + e.getMessage());
    }

    return messages;
}
}