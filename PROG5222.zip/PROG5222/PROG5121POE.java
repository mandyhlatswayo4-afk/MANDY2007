package com.mycompany.prog5121poe;

import java.util.ArrayList;
import java.util.Scanner;

public class PROG5121POE {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

ArrayList<Message> messages = new ArrayList<>();
ArrayList<Message> storedMessages = Message.loadStoredMessages();
ArrayList<Message> disregardedMessages = new ArrayList<>();

ArrayList<String> messageHashes = new ArrayList<>();
ArrayList<String> messageIDs = new ArrayList<>();
        boolean running = true;

        System.out.println("==================================");
        System.out.println("       Welcome to QuickChat");
        System.out.println("==================================");

        while (running) {

            System.out.println("\nPlease select an option:");
            System.out.println("1. Send Message");
            System.out.println("2. View Sent Messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Enter your choice: ");

            String choice = input.nextLine().trim();

            switch (choice) {

                case "1":

                    System.out.print("Enter recipient's phone number: ");
                    String recipient = input.nextLine().trim();

                    System.out.print("Enter your message (maximum 250 characters): ");
                    String messageText = input.nextLine();

                    if (messageText.length() > 250) {
                        int excess = messageText.length() - 250;

                        System.out.println(
                                "Message exceeds 250 characters by "
                                + excess
                                + "; please reduce the size."
                        );
                        break;
                    }

                    Message message = new Message(recipient, messageText);

                    String phoneResult = message.checkRecipientCell();

                    if (!phoneResult.equals(
                            "Cell phone number successfully captured.")) {
                        System.out.println(phoneResult);
                        break;
                    }

                    System.out.println(phoneResult);
                    System.out.println("Message ready to send.");

                    System.out.println("\nWhat would you like to do?");
                    System.out.println("1. Send Message");
                    System.out.println("2. Disregard Message");
                    System.out.println("3. Store Message");
                    System.out.print("Enter your choice: ");

                    String messageChoice = input.nextLine().trim();

                    switch (messageChoice) {

                       case "1":
    System.out.println(message.SentMessage("send"));

    messages.add(message);
    messageHashes.add(message.getMessageHash());
    messageIDs.add(message.getMessageID());

    System.out.println("\nMessage Details:");
    System.out.println(message.printMessages());

    break;
                       case "2":
    System.out.println(message.SentMessage("disregard"));
    disregardedMessages.add(message);
    break;
                        case "3":
     
 System.out.println(message.SentMessage("store"));

    storedMessages.add(message);
    messageHashes.add(message.getMessageHash());
    messageIDs.add(message.getMessageID());

    break;

                        default:
                            System.out.println(
                                    "Invalid choice. Please choose 1, 2, or 3.");
                            break;
                    }

                    break;

                case "2":

                    if (messages.isEmpty()) {
                        System.out.println("No sent messages to display.");
                    } else {
                        System.out.println("\nMessages Sent:");

                        for (Message sentMessage : messages) {
                            System.out.println(sentMessage.printMessages());
                            System.out.println("------------------------------");
                        }
                    }

                    break;
                    
                    case "3":
            
                        running = false;
                    System.out.println("Thank you for using QuickChat!");
                    break;

                



             
                   case "4":

    boolean storedMenu = true;

    while (storedMenu) {

        System.out.println("\nSTORED MESSAGES");
        System.out.println("1. Display longest stored message");
        System.out.println("2. Search by Message ID");
        System.out.println("3. Search by recipient");
        System.out.println("4. Delete message using hash");
        System.out.println("5. Display full report");
        System.out.println("6. Return to main menu");
        System.out.print("Choose an option: ");

        String storedChoice = input.nextLine().trim();

        switch (storedChoice) {

            case "1":
                if (storedMessages.isEmpty()) {
                    System.out.println("No stored messages found.");
                } else {
                    Message longest = storedMessages.get(0);

                    for (Message item : storedMessages) {
                        if (item.getMessageText().length()
                                > longest.getMessageText().length()) {
                            longest = item;
                        }
                    }

                    System.out.println("Longest message:");
                    System.out.println(longest.getMessageText());
                }
                break;

            case "2":
                System.out.print("Enter Message ID: ");
                String searchID = input.nextLine().trim();
                boolean idFound = false;

                for (Message item : storedMessages) {
                    if (item.getMessageID().equals(searchID)) {
                        System.out.println("Recipient: " + item.getRecipient());
                        System.out.println("Message: " + item.getMessageText());
                        idFound = true;
                    }
                }

                if (!idFound) {
                    System.out.println("Message ID not found.");
                }
                break;

            case "3":
                System.out.print("Enter recipient number: ");
                String searchRecipient = input.nextLine().trim();
                boolean recipientFound = false;

                for (Message item : storedMessages) {
                    if (item.getRecipient().equals(searchRecipient)) {
                        System.out.println(item.getMessageText());
                        recipientFound = true;
                    }
                }

                if (!recipientFound) {
                    System.out.println("No messages found for this recipient.");
                }
                break;

            case "4":
                System.out.print("Enter Message Hash: ");
                String searchHash = input.nextLine().trim();
                boolean deleted = false;

                for (int i = 0; i < storedMessages.size(); i++) {
                    if (storedMessages.get(i).getMessageHash()
                            .equalsIgnoreCase(searchHash)) {

                        System.out.println("Message: "
                                + storedMessages.get(i).getMessageText()
                                + " successfully deleted.");

                        storedMessages.remove(i);
                        deleted = true;
                        break;
                    }
                }

                if (!deleted) {
                    System.out.println("Message hash not found.");
                }
                break;

            case "5":
                if (storedMessages.isEmpty()) {
                    System.out.println("No stored messages found.");
                } else {
                    for (Message item : storedMessages) {
                        System.out.println("----------------------");
                        System.out.println("Message ID: " + item.getMessageID());
                        System.out.println("Message Hash: " + item.getMessageHash());
                        System.out.println("Recipient: " + item.getRecipient());
                        System.out.println("Message: " + item.getMessageText());
                    }
                }
                break;

            case "6":
                storedMenu = false;
                break;

            default:
                System.out.println("Invalid option.");
                break;
        }
    }

    break;

                    default:
    System.out.println(
        "Invalid option. Please select 1, 2, 3 or 4.");
    break;
}

}

System.out.println("\nTotal messages sent: " + messages.size());

input.close();

}
}